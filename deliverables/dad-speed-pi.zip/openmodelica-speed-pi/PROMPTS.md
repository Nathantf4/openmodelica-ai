# Frozen Astra prompts

Generate: Using only Modelica Standard Library 4.1.0, model J=0.2 kg.m2 rotational inertia with d=0.1 N.m.s/rad viscous damping. Track a 0 to 10 rad/s speed step at t=0.5 s using LimPID explicitly in PI mode, output limited to +/-5 N.m, initial speed and integrator state zero. Write model.mo and run.mos for a 3-second simulation. Check and simulate with the real compiler, preserve diagnostics and verify fresh finite results. Plot setpoint, speed and torque with units.

Retune: Keep exactly the same plant and limits. Change only k and Ti. Achieve less than 10% overshoot and enter the +/-2% speed band by absolute simulation time 2 s, remaining there through 3 s. Measure both gain pairs and IAE on 0..3 s. Do not silently accept ignored overrides or claim global optimality.

Repair fallback: Deliberately change controller.u_m to the nonexistent controller.u_measure in a separate copy. Say that this is a seeded error, show the actual compiler diagnostic, restore the verified connector and rerun. Do not pretend this was a spontaneous AI mistake.
