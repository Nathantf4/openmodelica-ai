# Public MSL speed PI example

Generated and rehearsed with Astra, OpenModelica 1.27.1 and Modelica Standard Library 4.1.0. No employer data, extra libraries or private corpus are included. Install OpenModelica and MSL 4.1.0 on the receiving machine.

Open model.mo in OMEdit to inspect the diagram and run the baseline. Open SpeedPIComparison.mo for a self-contained before/after comparison and plot setpoint, baselineSpeed and retunedSpeed; plot baselineTorque and retunedTorque separately.

For the two CSV runs, execute `omc run.mos` from this folder (not by opening the .mos as a model). It writes fresh baseline_res.csv and retuned_res.csv. OMC can return shell exit zero on errors: inspect diagnostics, actual output files and the measured trajectories. The original baseline.csv/retuned.csv and PNGs are retained reference evidence, not newly generated results.

See MEASUREMENTS.json for actual values and their finite-horizon definitions; PROMPTS.md contains the generation/retune/explicitly-seeded-repair prompts. Both runs hit the actuator limit. This demonstrates a controller including tracking anti-windup, not an isolated experimental estimate of anti-windup benefit.

The default model uses the intentionally poor baseline gains; the retuned case changes only k and Ti. Gain selection explored four pairs, not all possible controllers. No noise, delay, motor electrical dynamics or uncertain load was modeled. Compiler success is not engineering certification; this is a public textbook-style toy, not a site model or a replacement for specialist engineering tools.
